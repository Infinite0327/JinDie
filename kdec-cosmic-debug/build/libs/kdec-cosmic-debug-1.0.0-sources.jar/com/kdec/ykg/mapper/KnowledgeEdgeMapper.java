package com.kdec.ykg.mapper;

public class KnowledgeEdgeMapper {
}
