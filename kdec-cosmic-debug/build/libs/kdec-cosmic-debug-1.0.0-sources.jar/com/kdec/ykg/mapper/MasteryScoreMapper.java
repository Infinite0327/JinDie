package com.kdec.ykg.mapper;

public class MasteryScoreMapper {
}
