package com.kdec.ykg.mapper;

public class CourseMaterialMapper {
}
