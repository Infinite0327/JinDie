package com.kdec.ykg.Consumer;
//消费队友的答题完成消息 → 更新掌握度
public class AnswerEventConsumer {
}
