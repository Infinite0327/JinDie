package com.kdec.ykg.dto;

public class NodeExplainVO {
}
