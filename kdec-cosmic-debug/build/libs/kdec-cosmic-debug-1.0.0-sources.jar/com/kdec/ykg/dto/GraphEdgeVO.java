package com.kdec.ykg.dto;

public class GraphEdgeVO {
}
