package com.kdec.ykg.dto;

//含掌握度+染色的节点响应
public class GraphNodeVO {
}
