package com.kdec.ykg.schedule;
//每周一定时生成+推送简报
public class WeekReportScheduler {
}
