package com.kdec.ykg.controller.student;

// 入口1：上传课件，查解析状态
public class KnowledgeController {
}
