package com.kdec.ykg.controller.student;


//入口2：图谱导航、搜索、节点讲解
public class GraphController {
}
