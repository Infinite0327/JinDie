package com.kdec.ykg.controller.teacher;


//教师端2：学情简报查询
public class ReporterController {

}
