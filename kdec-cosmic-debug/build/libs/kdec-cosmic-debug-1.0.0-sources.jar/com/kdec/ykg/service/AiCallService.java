package com.kdec.ykg.service;
//统一AI调用封装
public class AiCallService {
}
