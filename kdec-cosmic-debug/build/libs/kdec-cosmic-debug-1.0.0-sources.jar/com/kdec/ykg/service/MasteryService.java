package com.kdec.ykg.service;

public class MasteryService {
}
