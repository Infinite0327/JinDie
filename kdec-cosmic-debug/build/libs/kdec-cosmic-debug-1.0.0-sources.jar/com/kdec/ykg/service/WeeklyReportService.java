package com.kdec.ykg.service;
//周报聚合逻辑
public class WeeklyReportService {
}
