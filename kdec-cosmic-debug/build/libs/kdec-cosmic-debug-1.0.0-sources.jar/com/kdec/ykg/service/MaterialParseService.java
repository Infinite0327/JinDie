package com.kdec.ykg.service;
//课件解析任务（调AI抽知识点）
public class MaterialParseService {
}
