package com.kdec.ykg.entity;
//课件
public class CourseMaterial {
}
