package com.kdec.ykg.entity;

public class MasteryScore {
}
