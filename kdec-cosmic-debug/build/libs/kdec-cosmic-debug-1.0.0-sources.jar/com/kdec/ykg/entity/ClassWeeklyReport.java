package com.kdec.ykg.entity;

public class ClassWeeklyReport {
}
