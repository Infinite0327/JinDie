package com.kdec.ykg.entity;
//知识点节点表
public class KnowledgeNode {
}
